import { env } from 'cloudflare:workers';
import { NextRequest, NextResponse } from 'next/server';

type SubmissionInput = { projectName:string; keyword:string; drugName:string; manager:string; bossGroup:string; startDate:string; endDate:string; contractAmount:number; imageUrl:string; landingUrl:string };
const seedSubmissions = [
  ['r001','心脑血管夏季守护','阿司匹林','拜阿司匹灵','李昕','慢病一组','2026-08-18','2026-09-18',680000,'https://img.example.com/aspirin.jpg','https://item.jd.com/10001.html','运行中','2026-08-11T09:20:00Z'],
  ['r002','开学季免疫力计划','维生素C','维C泡腾片','周遥','滋补营养组','2026-09-01','2026-09-30',420000,'https://img.example.com/vitamin-c.jpg','https://item.jd.com/10002.html','待配置','2026-08-29T04:35:00Z'],
  ['r003','秋季鼻敏感关怀','过敏性鼻炎','氯雷他定片','陈宁','OTC一组','2026-08-25','2026-09-08',360000,'https://img.example.com/allergy.jpg','https://item.jd.com/10003.html','即将到期','2026-08-18T08:10:00Z'],
  ['r004','肠胃轻松月','益生菌','复合益生菌粉','沈佳','消化二组','2026-09-10','2026-10-10',510000,'https://img.example.com/probiotic.jpg','https://item.jd.com/10004.html','待配置','2026-08-30T02:00:00Z'],
  ['r005','家庭常备止痛','布洛芬','布洛芬缓释胶囊','张琪','OTC二组','2026-07-15','2026-08-15',590000,'https://img.example.com/ibuprofen.jpg','https://item.jd.com/10005.html','已结束','2026-07-06T06:20:00Z'],
];
const seedMetrics = [
  ['阿司匹林','慢病一组',2860000,4380000,780000,720000,'S'],['维生素C','滋补营养组',1920000,2860000,560000,510000,'A'],['过敏性鼻炎','OTC一组',1680000,2190000,520000,485000,'A'],['益生菌','消化二组',1240000,1850000,460000,430000,'B'],['布洛芬','OTC二组',2180000,3260000,650000,598000,'S'],['钙片','滋补营养组',980000,1360000,380000,355000,'B'],
];
function datesBetween(start:string,end:string){ const dates:string[]=[]; const cursor=new Date(`${start}T00:00:00Z`); const last=new Date(`${end}T00:00:00Z`); while(cursor<=last&&dates.length<370){dates.push(cursor.toISOString().slice(0,10));cursor.setUTCDate(cursor.getUTCDate()+1)} return dates }
async function ensureDb(){
  const db=env.DB;
  await db.batch([
    db.prepare(`CREATE TABLE IF NOT EXISTS submissions (id TEXT PRIMARY KEY, project_name TEXT NOT NULL, keyword TEXT NOT NULL, drug_name TEXT NOT NULL, manager TEXT NOT NULL, boss_group TEXT NOT NULL, start_date TEXT NOT NULL, end_date TEXT NOT NULL, contract_amount INTEGER NOT NULL, image_url TEXT NOT NULL, landing_url TEXT NOT NULL, status TEXT NOT NULL, created_at TEXT NOT NULL)`),
    db.prepare(`CREATE TABLE IF NOT EXISTS keyword_allocations (keyword_date TEXT PRIMARY KEY, keyword TEXT NOT NULL, occupied_date TEXT NOT NULL, submission_id TEXT NOT NULL)`),
    db.prepare(`CREATE TABLE IF NOT EXISTS keyword_metrics (keyword TEXT PRIMARY KEY, boss_group TEXT NOT NULL, pv INTEGER NOT NULL, gmv INTEGER NOT NULL, price INTEGER NOT NULL, historical_average INTEGER NOT NULL, grade TEXT NOT NULL)`),
    db.prepare(`CREATE TABLE IF NOT EXISTS audit_logs (id INTEGER PRIMARY KEY AUTOINCREMENT, submission_id TEXT NOT NULL, action TEXT NOT NULL, actor TEXT NOT NULL, ip TEXT NOT NULL, created_at TEXT NOT NULL)`),
    db.prepare(`CREATE INDEX IF NOT EXISTS idx_submissions_keyword_dates ON submissions(keyword, start_date, end_date)`), db.prepare(`CREATE INDEX IF NOT EXISTS idx_submissions_status ON submissions(status)`),
  ]);
  const count=await db.prepare('SELECT COUNT(*) AS count FROM submissions').first<{count:number}>();
  if(!count?.count){
    await db.batch(seedSubmissions.map((row)=>db.prepare(`INSERT OR IGNORE INTO submissions VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)` ).bind(...row)));
    const allocations=seedSubmissions.flatMap((row)=>datesBetween(row[6] as string,row[7] as string).map((date)=>db.prepare('INSERT OR IGNORE INTO keyword_allocations VALUES (?, ?, ?, ?)').bind(`${row[2]}|${date}`,row[2],date,row[0])));
    for(let i=0;i<allocations.length;i+=80) await db.batch(allocations.slice(i,i+80));
  }
  await db.batch(seedMetrics.map((row)=>db.prepare(`INSERT OR IGNORE INTO keyword_metrics VALUES (?, ?, ?, ?, ?, ?, ?)` ).bind(...row)));
}
export async function GET(){ await ensureDb(); const [records,metrics,logs]=await Promise.all([env.DB.prepare('SELECT * FROM submissions ORDER BY start_date DESC').all(),env.DB.prepare('SELECT * FROM keyword_metrics ORDER BY pv DESC').all(),env.DB.prepare('SELECT * FROM audit_logs ORDER BY id DESC LIMIT 30').all()]); return NextResponse.json({records:records.results,metrics:metrics.results,logs:logs.results}) }
export async function POST(req:NextRequest){
  await ensureDb(); const input=await req.json() as SubmissionInput; const required=['projectName','keyword','drugName','manager','bossGroup','startDate','endDate','imageUrl','landingUrl'] as const;
  if(required.some((key)=>!String(input[key]??'').trim())||!input.contractAmount) return NextResponse.json({error:'请完整填写提报信息'},{status:400});
  if(input.endDate<input.startDate) return NextResponse.json({error:'结束日期不能早于开始日期'},{status:400});
  const conflict=await env.DB.prepare(`SELECT project_name, manager, end_date FROM submissions WHERE keyword = ? AND start_date <= ? AND end_date >= ? ORDER BY end_date DESC LIMIT 1`).bind(input.keyword.trim(),input.endDate,input.startDate).first<Record<string,string>>();
  if(conflict) return NextResponse.json({error:'关键词档期冲突',conflict},{status:409});
  const id=crypto.randomUUID(),now=new Date().toISOString(); const allocations=datesBetween(input.startDate,input.endDate).map((date)=>env.DB.prepare('INSERT INTO keyword_allocations VALUES (?, ?, ?, ?)').bind(`${input.keyword.trim()}|${date}`,input.keyword.trim(),date,id));
  try { await env.DB.batch([env.DB.prepare(`INSERT INTO submissions VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, '待配置', ?)`).bind(id,input.projectName.trim(),input.keyword.trim(),input.drugName.trim(),input.manager.trim(),input.bossGroup.trim(),input.startDate,input.endDate,Number(input.contractAmount),input.imageUrl.trim(),input.landingUrl.trim(),now),...allocations,env.DB.prepare(`INSERT INTO audit_logs (submission_id, action, actor, ip, created_at) VALUES (?, '创建提报', ?, ?, ?)`).bind(id,input.manager.trim(),req.headers.get('cf-connecting-ip')??'内部网络',now)]) }
  catch { const latest=await env.DB.prepare(`SELECT project_name, manager, end_date FROM submissions WHERE keyword = ? AND start_date <= ? AND end_date >= ? ORDER BY end_date DESC LIMIT 1`).bind(input.keyword.trim(),input.endDate,input.startDate).first(); return NextResponse.json({error:'关键词刚刚被其他同事占用',conflict:latest},{status:409}) }
  return NextResponse.json({ok:true,id});
}
export async function PATCH(req:NextRequest){ await ensureDb(); const {id,status,actor='收口人'}=await req.json() as {id:string;status:string;actor?:string}; const allowed=['待配置','已上线','运行中','已下线','已归档']; if(!id||!allowed.includes(status)) return NextResponse.json({error:'无效状态'},{status:400}); const now=new Date().toISOString(); await env.DB.batch([env.DB.prepare('UPDATE submissions SET status = ? WHERE id = ?').bind(status,id),env.DB.prepare(`INSERT INTO audit_logs (submission_id, action, actor, ip, created_at) VALUES (?, ?, ?, ?, ?)`).bind(id,`状态更新为${status}`,actor,req.headers.get('cf-connecting-ip')??'内部网络',now)]); return NextResponse.json({ok:true}) }
