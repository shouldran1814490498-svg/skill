CREATE TABLE `audit_logs` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`submission_id` text NOT NULL,
	`action` text NOT NULL,
	`actor` text NOT NULL,
	`ip` text NOT NULL,
	`created_at` text NOT NULL
);
--> statement-breakpoint
CREATE TABLE `keyword_allocations` (
	`keyword_date` text PRIMARY KEY NOT NULL,
	`keyword` text NOT NULL,
	`occupied_date` text NOT NULL,
	`submission_id` text NOT NULL
);
--> statement-breakpoint
CREATE TABLE `keyword_metrics` (
	`keyword` text PRIMARY KEY NOT NULL,
	`boss_group` text NOT NULL,
	`pv` integer NOT NULL,
	`gmv` integer NOT NULL,
	`price` integer NOT NULL,
	`historical_average` integer NOT NULL,
	`grade` text NOT NULL
);
--> statement-breakpoint
CREATE TABLE `submissions` (
	`id` text PRIMARY KEY NOT NULL,
	`project_name` text NOT NULL,
	`keyword` text NOT NULL,
	`drug_name` text NOT NULL,
	`manager` text NOT NULL,
	`boss_group` text NOT NULL,
	`start_date` text NOT NULL,
	`end_date` text NOT NULL,
	`contract_amount` integer NOT NULL,
	`image_url` text NOT NULL,
	`landing_url` text NOT NULL,
	`status` text DEFAULT '待配置' NOT NULL,
	`created_at` text NOT NULL
);
