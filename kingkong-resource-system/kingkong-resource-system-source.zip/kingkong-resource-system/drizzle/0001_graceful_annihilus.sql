CREATE INDEX `idx_audit_logs_submission` ON `audit_logs` (`submission_id`);--> statement-breakpoint
CREATE INDEX `idx_submissions_keyword_dates` ON `submissions` (`keyword`,`start_date`,`end_date`);--> statement-breakpoint
CREATE INDEX `idx_submissions_status` ON `submissions` (`status`);