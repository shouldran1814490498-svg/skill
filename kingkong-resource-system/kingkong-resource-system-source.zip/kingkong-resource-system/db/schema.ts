import { index, integer, sqliteTable, text } from 'drizzle-orm/sqlite-core';

export const submissions = sqliteTable('submissions', {
  id: text('id').primaryKey(), projectName: text('project_name').notNull(), keyword: text('keyword').notNull(),
  drugName: text('drug_name').notNull(), manager: text('manager').notNull(), bossGroup: text('boss_group').notNull(),
  startDate: text('start_date').notNull(), endDate: text('end_date').notNull(), contractAmount: integer('contract_amount').notNull(),
  imageUrl: text('image_url').notNull(), landingUrl: text('landing_url').notNull(), status: text('status').notNull().default('待配置'), createdAt: text('created_at').notNull(),
}, (table) => [index('idx_submissions_keyword_dates').on(table.keyword, table.startDate, table.endDate), index('idx_submissions_status').on(table.status)]);
export const keywordAllocations = sqliteTable('keyword_allocations', {
  keywordDate: text('keyword_date').primaryKey(), keyword: text('keyword').notNull(), occupiedDate: text('occupied_date').notNull(), submissionId: text('submission_id').notNull(),
});
export const keywordMetrics = sqliteTable('keyword_metrics', {
  keyword: text('keyword').primaryKey(), bossGroup: text('boss_group').notNull(), pv: integer('pv').notNull(), gmv: integer('gmv').notNull(), price: integer('price').notNull(), historicalAverage: integer('historical_average').notNull(), grade: text('grade').notNull(),
});
export const auditLogs = sqliteTable('audit_logs', {
  id: integer('id').primaryKey({ autoIncrement: true }), submissionId: text('submission_id').notNull(), action: text('action').notNull(), actor: text('actor').notNull(), ip: text('ip').notNull(), createdAt: text('created_at').notNull(),
}, (table) => [index('idx_audit_logs_submission').on(table.submissionId)]);
